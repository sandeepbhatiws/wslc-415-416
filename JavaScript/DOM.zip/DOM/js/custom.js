
// var output = document.getElementById('row1')
// // console.log(output.innerText)
// // console.log(output.innerHTML)
// document.getElementById('output').innerHTML = output.innerHTML;


var output = document.getElementsByClassName('row1');
console.log(output[2].innerText);
document.getElementById('output').innerHTML = output[2].innerText;