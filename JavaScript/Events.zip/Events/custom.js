function displayData(){
    console.log('Welcome to WsCube Tech');
}

function getValue(){
    var output = document.getElementById('input').value;
    console.log(output);
}