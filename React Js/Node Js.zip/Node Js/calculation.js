const add = () => {
    return 100;
}

const minus = () => {
    return -100;
}

// export default add;

export {add, minus}