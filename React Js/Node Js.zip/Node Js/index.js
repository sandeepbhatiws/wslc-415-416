console.log('Welcome to WS')

var a = 50;
var b = 10;


console.log(a+b);