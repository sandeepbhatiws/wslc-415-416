const data = () => {
    return "Hello";
}

var a = 10;
var b = 15;

// exports.module = a;

exports.module = {a, b, data};