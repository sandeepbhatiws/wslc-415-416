// const data = require('./data.js');



// console.log('About Us Pages');

// console.log(data.module.data());

// import add from "./calculation.js";

import {add, minus} from "./calculation.js";

console.log(add());
console.log(minus());