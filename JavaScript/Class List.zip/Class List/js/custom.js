// function addClass(){
//     document.getElementById('answer1').classList.add('d-none');
// }

// function removeClass(){
//     document.getElementById('answer2').classList.remove('d-none');
// }

// function toggleClass(){
//     document.getElementById('answer3').classList.toggle('d-none');
// }


function displayAnswer(i){
    document.getElementById('answer'+i).classList.toggle('d-none');
}